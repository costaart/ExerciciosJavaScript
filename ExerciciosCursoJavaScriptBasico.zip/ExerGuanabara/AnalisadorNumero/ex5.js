let numero = document.getElementById('formNum')
let lista = document.getElementById('formLista')
let resultado = document.getElementById('resultado')
let valores = []



function verificaNumero(numero){
    if(Number(numero) >=1 && Number(numero) <=100){
        return true
    } else {
        return false
    }
}

function verificaLista(numero, lista){
    if(lista.indexOf(Number(numero))!= -1){
        return true
    }else{
        return false
    }
}


function adicionar(){
    if(verificaNumero(numero.value) && !verificaLista(numero.value, valores)){
        valores.push(Number(numero.value))
        let item = document.createElement('option')
        item.text = `Valor ${numero.value} adicionado.`
        lista.appendChild(item)     
        resultado.innerHTML = '' 


    } else{
        alert('Valor inválido ou já presente na lista!')
    }
    numero.value = ''
    numero.focus()
}

function finalizar(){
    if(valores.length == 0){
        alert('Adicione valores antes de finalizar!')
    } else { 
        let total = valores.length
        let maiorNum = valores[0]
        let menorNum = valores[0]
        let soma = 0
        let media = 0


        
        for(let pos in valores){
        soma += valores[pos]    
        
            if(valores[pos] > maiorNum){
                maiorNum = valores[pos]
            }if(valores[pos] < menorNum){
                menorNum = valores[pos]
            }
        }

        media = soma / total


        resultado.innerHTML = ''
        resultado.innerHTML += `<p> No total, temos ${total} números inseridos.</p>`
        resultado.innerHTML += `<p> - O maior valor inserido foi ${maiorNum}.</p>`
        resultado.innerHTML += `<p> - O menor valor inserido foi ${menorNum}.</p>`
        resultado.innerHTML += `<p> - A soma dos valores inseridos são ${soma}.</p>`
        resultado.innerHTML += `<p> - A média entre os valores inseridos são ${media}.</p>`



    }   
}