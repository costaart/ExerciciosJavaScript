function tabuada(){
    let numero = document.getElementById('txtNum')      //Pega os campos 
    let tabuada = document.getElementById('selTab')

    if(numero.value.legth == 0 ){               //Caso nao informe número aparece erro
        alert('Por favor, digite um número!')
    } else {
        let numeroConvertido = Number(numero.value)     //Converte para tipo NUMBER
        tabuada.innerHTML = ''                          //Limpa o campo 
        for (i = 1; i<=10; i++){
            let aux = document.createElement('option')  //Cria os campos na section
                    aux.text = `${numeroConvertido} x ${i} = ${numeroConvertido*i}` //calcula a tabuada
                    tabuada.appendChild(aux)            //adiciona o próximo embaixo
        }


    }
    
}       




