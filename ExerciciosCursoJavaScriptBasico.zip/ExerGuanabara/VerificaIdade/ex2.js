function verificar(){
    
    var data = new Date()
    var ano = data.getFullYear()
    var usuarioAno = document.getElementById('txtAno')
    var resultado = document.querySelector('div#resultado')

    var imagem = document.createElement('img')
    imagem.setAttribute('id', 'foto')


    if(usuarioAno.value.length == 0 || Number(usuarioAno.value) > ano){
        window.alert('[ERRO] Verifique os dados e tente novamente!')
    } else{
        usuarioSexo = document.getElementsByName('sex')
        var idade = ano - Number(usuarioAno.value)
        var genero =''

        if(usuarioSexo[0].checked){
            genero = 'Homem'
            if(idade>=0 && idade<13){
                imagem.setAttribute('src', 'fotos/bebehomem.png')
            } else if (idade < 21){
                imagem.setAttribute('src', 'fotos/jovemhomem.png')
            } else if (idade < 65){
                imagem.setAttribute('src', 'fotos/adultohomem.png')
            } else {
                imagem.setAttribute('src', 'fotos/velhohomem.png')
            }
             

        } else{
            genero = 'Mulher'
            if(idade>=0 && idade<13){
                imagem.setAttribute('src', 'fotos/bebemulher.png')
            } else if (idade < 21){
                imagem.setAttribute('src', 'fotos/jovemmulher.png')
            } else if (idade <65){
                imagem.setAttribute('src', 'fotos/adultamulher.png')
            } else {
                imagem.setAttribute('src', 'fotos/idosamulher.png')
            }
        }
        resultado.style.textAlign = 'center'
        imagem.style.padding = '17px'
        resultado.innerHTML = `Detectamos um(a) ${genero} com ${idade} anos.`
        resultado.appendChild(imagem)

    }



}