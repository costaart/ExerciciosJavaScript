function carregar(){                                //carregam as imagens logo ao iniciar o site
var msg = document.getElementById('msg')
var img = document.getElementById('imagem')

var data = new Date()           //pega a data do sistema
var hora = data.getHours()      //pega a hora do sistema
var minuto = data.getMinutes()  //pega o minuto do sistema



if(hora>=0 && hora <12){                        //condições para mostrar se está de manha, tarde ou noite
    msg.innerText = 'Você está de noite!'
    img.scr = 'manha.png'
    msg.innerHTML = `Agora são ${hora} horas e ${minuto} minutos! <p> Tenha um maravilhoso dia! </p> `
    document.body.style.background = '#e2cd9f'
} else if(hora >=12 && hora<=18){
    img.scr = 'tarde.png'
    msg.innerHTML = `Agora são ${hora} horas e ${minuto} minutos! <p> Tenha uma bela tarde! </p> `
    document.body.style.background = '#b9846f'
} else{
    img.src = 'noite.png'
    msg.innerHTML = `Agora são ${hora} horas e ${minuto} minutos! <p> Tenha uma ótima noite! </p> `
    document.body.style.background = '#515154'
}

}
