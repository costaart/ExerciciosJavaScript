function contar() {
    //let = so vale aqui dentro
    let inicio = document.getElementById('txtInicio')
    let fim = document.getElementById('txtFim')
    let passo = document.getElementById('txtPasso')
    let resultado = document.getElementById('resultado')

    if (inicio.value.lenght == 0 || fim.value.length == 0 || passo.value.length == 0){
        resultado.innerHTML = 'Impossível contar!'

    } else {
        resultado.innerHTML = 'Contando: <br> '
        let i = Number(inicio.value)
        let f = Number(fim.value)       //Pegando os valores que estão em STRING e passando para NUMBER
        let p = Number(passo.value)
        if(p <= 0 ){
            alert('Passo inválido! Vou considerar como PASSO 1')
            p = 1
        }

        if(i < f) { //Contagem crescente
            for(c = i; c <=f; c+=p){
                resultado.innerHTML += `${c} \u{1F449} `
            }
            resultado.innerHTML += `\u{1F3C1}` //Bandeirinha
        } else {
            for(c = i; c>=f; c -= p){   //Contagem regressiva
                resultado.innerHTML += `${c} \u{1F449}`

            }
        }
        resultado.innerHTML += `\u{1F3C1}`  //Bandeirinha
    }
}